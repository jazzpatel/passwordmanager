// ─── State ───────────────────────────────────────────────────────────────────
let cryptoKey = null;
let credentials = []; // decrypted in-memory credential store
let folders = []; // folder store
let currentId = null; // credential being viewed
let editingId = null; // credential being edited (null = new)
let currentFolderId = null; // folder currently open in main pane
let searchQuery = "";
let toastTimer = null;
let autoLockTimer = null;

// ─── Constants ───────────────────────────────────────────────────────────────
const DB_NAME = "KeyVaultDB";
const STORE_NAME = "credentials";
const META_KEY = "meta";
const VAULT_KEY = "vault_v2";

const CATEGORIES = {
  Work: "💼",
  Social: "📱",
  Finance: "💰",
  Email: "📧",
  Shopping: "🛒",
  Entertainment: "🎮",
  Other: "📝",
};
const CAT_ORDER = Object.keys(CATEGORIES);

const SETTINGS_KEY = "keyvault_settings";
const TIMEOUT_OPTIONS = [
  { label: "1 minute", value: 1 },
  { label: "5 minutes", value: 5 },
  { label: "15 minutes", value: 15 },
  { label: "30 minutes", value: 30 },
  { label: "1 hour", value: 60 },
  { label: "4 hours", value: 240 },
  { label: "Never", value: 0 },
];

// ─── Settings helpers ─────────────────────────────────────────────────────────
function loadSettings() {
  try {
    return JSON.parse(localStorage.getItem(SETTINGS_KEY)) || {};
  } catch {
    return {};
  }
}
function saveSettings(s) {
  localStorage.setItem(SETTINGS_KEY, JSON.stringify(s));
}

// ─── Auto-lock ────────────────────────────────────────────────────────────────
function getAutoLockMs() {
  const mins = loadSettings().autoLockMinutes ?? 15; // default 15 min
  return mins === 0 ? 0 : mins * 60 * 1000;
}
function startAutoLock() {
  clearAutoLock();
  const ms = getAutoLockMs();
  if (!ms) return; // "Never" option
  autoLockTimer = setTimeout(() => {
    if (cryptoKey) lockVault("timeout");
  }, ms);
}
function resetAutoLock() {
  if (cryptoKey) startAutoLock();
}
function clearAutoLock() {
  clearTimeout(autoLockTimer);
  autoLockTimer = null;
}

// Reset inactivity timer on any user interaction
["mousedown", "keydown", "touchstart", "scroll"].forEach((evt) =>
  document.addEventListener(evt, resetAutoLock, { passive: true }),
);

// ─── IndexedDB helpers ────────────────────────────────────────────────────────
function openDB() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, 2);
    req.onupgradeneeded = (e) => {
      const db = e.target.result;
      if (!db.objectStoreNames.contains(STORE_NAME))
        db.createObjectStore(STORE_NAME);
    };
    req.onsuccess = (e) => resolve(e.target.result);
    req.onerror = (e) => reject(e);
  });
}

async function dbGet(key) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const req = db
      .transaction(STORE_NAME, "readonly")
      .objectStore(STORE_NAME)
      .get(key);
    req.onsuccess = (e) => resolve(e.target.result);
    req.onerror = (e) => reject(e);
  });
}

async function dbPut(key, value) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const req = db
      .transaction(STORE_NAME, "readwrite")
      .objectStore(STORE_NAME)
      .put(value, key);
    req.onsuccess = () => resolve();
    req.onerror = (e) => reject(e);
  });
}

// Write multiple entries atomically in a single transaction
async function dbPutMultiple(entries) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, "readwrite");
    const store = tx.objectStore(STORE_NAME);
    for (const { key, value } of entries) store.put(value, key);
    tx.oncomplete = () => resolve();
    tx.onerror = (e) => reject(e);
    tx.onabort = (e) => reject(e);
  });
}

// ─── Crypto ───────────────────────────────────────────────────────────────────
async function deriveKey(password, salt) {
  const enc = new TextEncoder();
  const keyMaterial = await crypto.subtle.importKey(
    "raw",
    enc.encode(password),
    "PBKDF2",
    false,
    ["deriveKey"],
  );
  return crypto.subtle.deriveKey(
    { name: "PBKDF2", salt, iterations: 310_000, hash: "SHA-256" },
    keyMaterial,
    { name: "AES-GCM", length: 256 },
    false,
    ["encrypt", "decrypt"],
  );
}

async function encryptVault(data) {
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const enc = new TextEncoder();
  const encrypted = await crypto.subtle.encrypt(
    { name: "AES-GCM", iv },
    cryptoKey,
    enc.encode(JSON.stringify(data)),
  );
  return { iv: Array.from(iv), data: Array.from(new Uint8Array(encrypted)) };
}

async function decryptVault(payload) {
  const iv = new Uint8Array(payload.iv);
  const decrypted = await crypto.subtle.decrypt(
    { name: "AES-GCM", iv },
    cryptoKey,
    new Uint8Array(payload.data),
  );
  return JSON.parse(new TextDecoder().decode(decrypted));
}

// ─── Auth ─────────────────────────────────────────────────────────────────────
async function handleAuth() {
  const pwd = document.getElementById("master-password").value;
  if (!pwd) return;

  const statusEl = document.getElementById("auth-status");
  setAuthStatus("");

  // Disable button during processing
  const btn = document.getElementById("btn-unlock");
  btn.disabled = true;
  btn.textContent = "Unlocking…";

  try {
    // Get or create salt
    let meta = await dbGet(META_KEY);
    let salt;
    if (meta) {
      salt = new Uint8Array(meta.salt);
    } else {
      salt = crypto.getRandomValues(new Uint8Array(16));
      await dbPut(META_KEY, { salt: Array.from(salt) });
    }

    cryptoKey = await deriveKey(pwd, salt);

    // Try loading existing vault
    const existing = await dbGet(VAULT_KEY);
    if (existing) {
      try {
        const raw = await decryptVault(existing);
        // Support old format (plain array) and new format ({ credentials, folders })
        if (Array.isArray(raw)) {
          credentials = raw;
          folders = [];
        } else {
          credentials = raw.credentials || [];
          folders = raw.folders || [];
        }
      } catch {
        // Wrong password
        cryptoKey = null;
        setAuthStatus("error", "❌  Incorrect password — please try again.");
        document.getElementById("master-password").value = "";
        return;
      }
    } else {
      // Attempt migration from v1 individual-key format
      credentials = await migrateV1();
      if (credentials.length > 0) {
        await persistVault();
      }
    }

    // ── Success ──
    setAuthStatus("success", "✅  Vault unlocked successfully!");
    setTimeout(() => {
      document.getElementById("auth-overlay").classList.add("hidden");
      document.getElementById("app").classList.remove("hidden");
      renderSidebar();
      showWelcomeOrFirst();
      startAutoLock();
    }, 650);
  } catch (err) {
    console.error(err);
    setAuthStatus(
      "error",
      "⚠️  Crypto error — make sure you are on HTTPS or localhost.",
    );
  } finally {
    btn.disabled = false;
    btn.textContent = "Unlock Vault";
  }
}

function setAuthStatus(type, msg = "") {
  const el = document.getElementById("auth-status");
  el.className = type ? `visible ${type}` : "";
  el.textContent = msg;
}

function lockVault(reason = "") {
  clearAutoLock();
  cryptoKey = null;
  credentials = [];
  folders = [];
  currentId = null;
  editingId = null;
  currentFolderId = null;
  searchQuery = "";
  document.getElementById("master-password").value = "";
  document.getElementById("search-input").value = "";
  setAuthStatus("");
  document.getElementById("app").classList.add("hidden");
  document.getElementById("auth-overlay").classList.remove("hidden");
  if (reason === "timeout") {
    setAuthStatus("error", "⏱  Vault locked due to inactivity.");
  }
  document.getElementById("master-password").focus();
}

// ─── v1 migration ─────────────────────────────────────────────────────────────
async function migrateV1() {
  const db = await openDB();
  return new Promise((resolve) => {
    const tx = db.transaction(STORE_NAME, "readonly");
    const req = tx.objectStore(STORE_NAME).openCursor();
    const migrated = [];

    req.onsuccess = async (e) => {
      const cursor = e.target.result;
      if (!cursor) {
        resolve(migrated);
        return;
      }

      const key = cursor.key;
      if (key !== META_KEY && key !== VAULT_KEY) {
        try {
          // Old format: { salt, iv, data } — decrypt using current key
          const plain = await decryptVault(cursor.value);
          const now = Date.now();
          migrated.push({
            id: await generateHashId(plain.site, plain.user, plain.pass),
            site: plain.site || String(key),
            user: plain.user || "",
            pass: plain.pass || "",
            url: "",
            category: "Other",
            notes: "",
            createdAt: now,
            updatedAt: now,
          });
        } catch {
          /* skip undecryptable keys */
        }
      }
      cursor.continue();
    };
    req.onerror = () => resolve([]);
  });
}

// ─── Vault persistence ────────────────────────────────────────────────────────
async function persistVault() {
  const payload = await encryptVault({ credentials, folders });
  await dbPut(VAULT_KEY, payload);
}

// ─── Credential CRUD ──────────────────────────────────────────────────────────
function genId() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2);
}

async function generateHashId(site, user, password, length = null) {
  // 1. Combine with a delimiter to prevent collisions
  const combinedString = `${site}:${user}:${password}`;

  // 2. Convert string to Uint8Array (required by Web Crypto)
  const encoder = new TextEncoder();
  const data = encoder.encode(combinedString);

  // 3. Generate the hash buffer
  const hashBuffer = await crypto.subtle.digest("SHA-256", data);

  // 4. Convert the buffer to a hexadecimal string
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  const hashHex = hashArray
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");

  // 5. Return truncated hash if length is provided
  return length ? hashHex.substring(0, length) : hashHex;
}

async function saveCredential() {
  const site = document.getElementById("f-site").value.trim();
  const pass = document.getElementById("f-pass").value;
  const user = document.getElementById("f-user").value.trim();
  const url = document.getElementById("f-url").value.trim();
  const category = document.getElementById("f-cat").value;
  const notes = document.getElementById("f-notes").value.trim();
  const folderId = document.getElementById("f-folder").value || null;

  if (!site || !pass) {
    showToast("Please enter at least a website name and password.");
    return;
  }

  const now = Date.now();
  if (editingId) {
    const idx = credentials.findIndex((c) => c.id === editingId);
    if (idx !== -1) {
      credentials[idx] = {
        ...credentials[idx],
        site,
        user,
        pass,
        url,
        category,
        notes,
        folderId,
        updatedAt: now,
      };
    }
    currentId = editingId;
    editingId = null;
  } else {
    const newId = await generateHashId(site, user, pass);
    if (credentials.some((c) => c.id === newId)) {
      showToast(
        "⚠️  A credential with this exact site, username, and password already exists.",
        3500,
      );
      return;
    }
    const cred = {
      id: newId,
      site,
      user,
      pass,
      url,
      category,
      notes,
      folderId,
      createdAt: now,
      updatedAt: now,
    };
    credentials.push(cred);
    currentId = cred.id;
  }

  await persistVault();
  renderSidebar();
  showDetail(currentId);
  showToast("Credential saved ✓");
}

async function deleteCurrentCredential() {
  if (!currentId) return;
  if (!confirm("Delete this credential? This cannot be undone.")) return;
  credentials = credentials.filter((c) => c.id !== currentId);
  await persistVault();
  currentId = null;
  editingId = null;
  renderSidebar();
  showWelcomeOrFirst();
  showToast("Credential deleted.");
}

// ─── Views ────────────────────────────────────────────────────────────────────
function hideAll() {
  [
    "welcome-state",
    "detail-view",
    "form-view",
    "io-view",
    "settings-view",
    "folder-view",
  ].forEach((id) => {
    document.getElementById(id).style.display = "none";
  });
}

function showWelcomeOrFirst() {
  currentFolderId = null;
  hideAll();
  if (credentials.length === 0 && folders.length === 0) {
    document.getElementById("welcome-state").style.display = "flex";
  } else if (credentials.length > 0) {
    showDetail(credentials[0].id);
  } else {
    showFolderView(folders[0].id);
  }
}

function showDetail(id) {
  const cred = credentials.find((c) => c.id === id);
  if (!cred) {
    showWelcomeOrFirst();
    return;
  }

  currentId = id;
  editingId = null;
  hideAll();

  // Highlight active sidebar item
  document
    .querySelectorAll(".nav-cred")
    .forEach((el) => el.classList.toggle("active", el.dataset.id === id));

  // Populate detail panel
  const av = document.getElementById("dtl-av");
  av.textContent = cred.site.charAt(0).toUpperCase();
  av.style.background = avatarColor(cred.site);

  document.getElementById("dtl-title").textContent = cred.site;
  document.getElementById("dtl-cat").textContent =
    `${CATEGORIES[cred.category] || "📝"} ${cred.category || "Other"}`;
  document.getElementById("dtl-site").textContent = cred.site;
  document.getElementById("dtl-user").textContent = cred.user || "—";

  // Password — always start hidden
  const passEl = document.getElementById("dtl-pass");
  passEl.textContent = "••••••••••••";
  passEl.dataset.pass = cred.pass;
  passEl.dataset.shown = "false";
  document.getElementById("pass-toggle-btn").textContent = "Show";

  // URL
  const urlRow = document.getElementById("dtl-url-row");
  const urlEl = document.getElementById("dtl-url");
  if (cred.url) {
    urlRow.style.display = "flex";
    const href = cred.url.startsWith("http") ? cred.url : "https://" + cred.url;
    urlEl.innerHTML = `<a href="${escHtml(href)}" target="_blank" rel="noopener">${escHtml(cred.url)}</a>`;
  } else {
    urlRow.style.display = "none";
  }

  // Notes
  const notesCard = document.getElementById("dtl-notes-card");
  if (cred.notes) {
    notesCard.style.display = "block";
    document.getElementById("dtl-notes").textContent = cred.notes;
  } else {
    notesCard.style.display = "none";
  }

  // Timestamps
  document.getElementById("dtl-created").textContent =
    `📅 Created: ${fmtDate(cred.createdAt)}`;
  document.getElementById("dtl-updated").textContent =
    `✏️ Updated: ${fmtDate(cred.updatedAt)}`;

  // Folder badge — clickable link back to the folder view
  const folderBadge = document.getElementById("dtl-folder-badge");
  if (cred.folderId) {
    const folder = getFolderById(cred.folderId);
    if (folder) {
      folderBadge.style.display = "inline-flex";
      folderBadge.textContent = `📂 ${folder.name}`;
      folderBadge.onclick = () => showFolderView(cred.folderId);
    } else {
      folderBadge.style.display = "none";
    }
  } else {
    folderBadge.style.display = "none";
  }

  document.getElementById("detail-view").style.display = "block";
}

function showAddForm(folderId = null) {
  editingId = null;
  hideAll();
  clearActiveNav();
  document.getElementById("form-title").textContent = "Add Credential";
  document.getElementById("f-site").value = "";
  document.getElementById("f-user").value = "";
  document.getElementById("f-pass").value = "";
  document.getElementById("f-url").value = "";
  document.getElementById("f-cat").value = "Other";
  document.getElementById("f-notes").value = "";
  document.getElementById("form-del-btn").hidden = true;
  document.getElementById("f-pass").type = "password";
  populateFolderSelect(folderId ?? currentFolderId);
  document.getElementById("form-view").style.display = "block";
  document.getElementById("f-site").focus();
}

function editCurrentCredential() {
  const cred = credentials.find((c) => c.id === currentId);
  if (!cred) return;
  editingId = currentId;
  hideAll();
  document.getElementById("form-title").textContent = "Edit Credential";
  document.getElementById("f-site").value = cred.site;
  document.getElementById("f-user").value = cred.user || "";
  document.getElementById("f-pass").value = cred.pass;
  document.getElementById("f-url").value = cred.url || "";
  document.getElementById("f-cat").value = cred.category || "Other";
  document.getElementById("f-notes").value = cred.notes || "";
  document.getElementById("form-del-btn").hidden = false;
  document.getElementById("f-pass").type = "password";
  populateFolderSelect(cred.folderId || null);
  document.getElementById("form-view").style.display = "block";
  document.getElementById("f-site").focus();
}

function cancelForm() {
  editingId = null;
  if (currentId) showDetail(currentId);
  else showWelcomeOrFirst();
}

function showIOView() {
  hideAll();
  clearActiveNav();
  populateIOFolderSelects();
  document.getElementById("io-view").style.display = "block";
}

// ─── Sidebar ──────────────────────────────────────────────────────────────────
const collapsedFolders = new Set(); // folder IDs collapsed in the sidebar

function clearActiveNav() {
  document
    .querySelectorAll(".nav-cred, .nav-folder-hdr")
    .forEach((el) => el.classList.remove("active"));
}

function handleSearch(val) {
  searchQuery = val;
  renderSidebar();
}

function populateFolderSelect(selectedId = null) {
  const sel = document.getElementById("f-folder");
  if (!sel) return;
  const sorted = [...folders].sort((a, b) => a.name.localeCompare(b.name));
  sel.innerHTML =
    `<option value="">— No Folder —</option>` +
    sorted
      .map(
        (f) =>
          `<option value="${escHtml(f.id)}"${f.id === selectedId ? " selected" : ""}>${escHtml(f.name)}</option>`,
      )
      .join("");
}

function renderSidebar() {
  const nav = document.getElementById("categories-nav");
  const query = searchQuery.toLowerCase();
  nav.innerHTML = "";

  const filtered = query
    ? credentials.filter(
        (c) =>
          c.site.toLowerCase().includes(query) ||
          (c.user || "").toLowerCase().includes(query) ||
          (c.category || "").toLowerCase().includes(query) ||
          (c.notes || "").toLowerCase().includes(query),
      )
    : credentials;

  // ── All Items ──
  const allRow = document.createElement("div");
  allRow.className = "nav-all";
  allRow.innerHTML = `<span>🔐</span><span style="flex:1">All Items</span>
    <span class="nav-all-count">${filtered.length}</span>`;
  allRow.onclick = () => {
    clearActiveNav();
    allRow.classList.add("active");
    currentFolderId = null;
    if (filtered.length) showDetail(filtered[0].id);
    else {
      hideAll();
      document.getElementById("welcome-state").style.display = "flex";
    }
  };
  nav.appendChild(allRow);

  // ── Folders section header ──
  const secHdr = document.createElement("div");
  secHdr.className = "nav-section-hdr";
  secHdr.innerHTML = `
    <span class="nav-section-lbl">Folders</span>
    <button class="nav-add-folder-btn" onclick="startFolderCreate()" title="New folder">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"
           stroke-width="2.5" stroke-linecap="round">
        <line x1="12" y1="5" x2="12" y2="19"/>
        <line x1="5"  y1="12" x2="19" y2="12"/>
      </svg>
    </button>`;
  nav.appendChild(secHdr);

  // ── Named folders ──
  const sortedFolders = [...folders].sort((a, b) =>
    a.name.localeCompare(b.name),
  );
  for (const folder of sortedFolders) {
    const folderCreds = filtered.filter((c) => c.folderId === folder.id);
    nav.appendChild(buildFolderSection(folder, folderCreds));
  }

  // ── No Folder (unfiled) ──
  const unfiled = filtered.filter((c) => !c.folderId);
  if (unfiled.length > 0 || folders.length === 0) {
    nav.appendChild(buildUnfiledSection(unfiled));
  }
}

function buildFolderSection(folder, creds) {
  const collapsed = collapsedFolders.has(folder.id);
  const isActive = currentFolderId === folder.id;
  const section = document.createElement("div");
  section.className = `nav-folder${collapsed ? " collapsed" : ""}`;
  section.dataset.id = folder.id;

  section.innerHTML = `
    <div class="nav-folder-hdr${isActive ? " active" : ""}">
      <svg class="nav-folder-chevron" viewBox="0 0 24 24" fill="none"
           stroke="currentColor" stroke-width="2.5" stroke-linecap="round"
           stroke-linejoin="round"
           onclick="event.stopPropagation(); toggleFolder('${folder.id}')">
        <polyline points="6 9 12 15 18 9"/>
      </svg>
      <svg class="nav-folder-ico" viewBox="0 0 24 24" fill="none"
           stroke="currentColor" stroke-width="2" stroke-linecap="round"
           stroke-linejoin="round">
        <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/>
      </svg>
      <span class="nav-folder-name"
            onclick="showFolderView('${folder.id}')">${escHtml(folder.name)}</span>
      <span class="nav-folder-count">${creds.length}</span>
      <div class="nav-folder-acts">
        <button class="nav-folder-act" title="Rename"
                onclick="event.stopPropagation(); startFolderRename('${folder.id}')">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
               stroke-linecap="round" stroke-linejoin="round">
            <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/>
            <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/>
          </svg>
        </button>
        <button class="nav-folder-act danger" title="Delete"
                onclick="event.stopPropagation(); deleteFolder('${folder.id}')">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
               stroke-linecap="round" stroke-linejoin="round">
            <polyline points="3 6 5 6 21 6"/>
            <path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/>
          </svg>
        </button>
      </div>
    </div>
    <div class="nav-folder-items"></div>`;

  const itemsEl = section.querySelector(".nav-folder-items");
  for (const cred of creds) itemsEl.appendChild(buildCredItem(cred));
  return section;
}

function buildUnfiledSection(creds) {
  const collapsed = collapsedFolders.has("__unfiled__");
  const section = document.createElement("div");
  section.className = `nav-folder${collapsed ? " collapsed" : ""}`;
  section.dataset.id = "__unfiled__";

  section.innerHTML = `
    <div class="nav-folder-hdr">
      <svg class="nav-folder-chevron" viewBox="0 0 24 24" fill="none"
           stroke="currentColor" stroke-width="2.5" stroke-linecap="round"
           stroke-linejoin="round"
           onclick="event.stopPropagation(); toggleFolder('__unfiled__')">
        <polyline points="6 9 12 15 18 9"/>
      </svg>
      <svg class="nav-folder-ico" viewBox="0 0 24 24" fill="none"
           stroke="currentColor" stroke-width="2" stroke-linecap="round"
           stroke-linejoin="round" style="color:var(--text-3)">
        <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/>
      </svg>
      <span class="nav-folder-name" style="color:var(--text-2)">No Folder</span>
      <span class="nav-folder-count">${creds.length}</span>
      <div class="nav-folder-acts"></div>
    </div>
    <div class="nav-folder-items"></div>`;

  const itemsEl = section.querySelector(".nav-folder-items");
  for (const cred of creds) itemsEl.appendChild(buildCredItem(cred));
  return section;
}

function buildCredItem(cred) {
  const item = document.createElement("div");
  item.className = "nav-cred" + (cred.id === currentId ? " active" : "");
  item.dataset.id = cred.id;
  item.innerHTML = `
    <div class="nav-cred-av" style="background:${avatarColor(cred.site)}">
      ${escHtml(cred.site.charAt(0).toUpperCase())}
    </div>
    <div class="nav-cred-text">
      <div class="nav-cred-name">${escHtml(cred.site)}</div>
      <div class="nav-cred-user">${escHtml(cred.user || "")}</div>
    </div>`;
  item.onclick = () => showDetail(cred.id);
  return item;
}

function toggleFolder(id) {
  collapsedFolders.has(id)
    ? collapsedFolders.delete(id)
    : collapsedFolders.add(id);
  const el = document.querySelector(`.nav-folder[data-id="${CSS.escape(id)}"]`);
  if (el) el.classList.toggle("collapsed");
}

// ─── Folder CRUD ──────────────────────────────────────────────────────────────
function getFolderById(id) {
  return folders.find((f) => f.id === id) || null;
}

function startFolderCreate() {
  if (document.getElementById("new-folder-inp")) return; // already open
  const secHdr = document.querySelector("#categories-nav .nav-section-hdr");
  if (!secHdr) return;
  const row = document.createElement("div");
  row.className = "nav-folder-create-row";
  row.innerHTML = `
    <input class="nav-folder-inp" id="new-folder-inp"
           placeholder="Folder name…" maxlength="40" />
    <button class="nav-folder-inp-ok"     onclick="confirmFolderCreate()" title="Create">✓</button>
    <button class="nav-folder-inp-cancel" onclick="renderSidebar()"       title="Cancel">✗</button>`;
  secHdr.insertAdjacentElement("afterend", row);
  const inp = document.getElementById("new-folder-inp");
  inp.focus();
  inp.addEventListener("keydown", (e) => {
    if (e.key === "Enter") confirmFolderCreate();
    if (e.key === "Escape") renderSidebar();
  });
}

async function confirmFolderCreate() {
  const inp = document.getElementById("new-folder-inp");
  if (!inp) return;
  const name = inp.value.trim();
  if (!name) {
    renderSidebar();
    return;
  }
  const folder = {
    id: genId(),
    name,
    createdAt: Date.now(),
    updatedAt: Date.now(),
  };
  folders.push(folder);
  await persistVault();
  renderSidebar();
  showFolderView(folder.id);
  showToast(`Folder "${name}" created.`);
}

function startFolderRename(folderId) {
  const folder = getFolderById(folderId);
  if (!folder) return;
  const nameEl = document.querySelector(
    `.nav-folder[data-id="${CSS.escape(folderId)}"] .nav-folder-name`,
  );
  if (!nameEl) return;
  const inp = document.createElement("input");
  inp.className = "nav-folder-inp";
  inp.style.flex = "1";
  inp.value = folder.name;
  inp.maxLength = 40;
  nameEl.replaceWith(inp);
  inp.focus();
  inp.select();
  let done = false;
  const commit = async () => {
    if (done) return;
    done = true;
    const n = inp.value.trim();
    if (n && n !== folder.name) {
      folder.name = n;
      folder.updatedAt = Date.now();
      await persistVault();
      showToast(`Renamed to "${n}".`);
    }
    renderSidebar();
    if (currentFolderId === folderId) showFolderView(folderId);
  };
  inp.addEventListener("keydown", (e) => {
    if (e.key === "Enter") {
      e.preventDefault();
      commit();
    }
    if (e.key === "Escape") {
      done = true;
      renderSidebar();
    }
  });
  inp.addEventListener("blur", () => setTimeout(commit, 150));
}

async function deleteFolder(folderId) {
  const folder = getFolderById(folderId);
  if (!folder) return;
  const count = credentials.filter((c) => c.folderId === folderId).length;
  const msg =
    count > 0
      ? `Delete "${folder.name}"? Its ${count} credential${count !== 1 ? "s" : ""} will be moved to "No Folder".`
      : `Delete folder "${folder.name}"?`;
  if (!confirm(msg)) return;
  credentials.forEach((c) => {
    if (c.folderId === folderId) c.folderId = null;
  });
  folders = folders.filter((f) => f.id !== folderId);
  await persistVault();
  if (currentFolderId === folderId) currentFolderId = null;
  renderSidebar();
  showWelcomeOrFirst();
  showToast(`Folder "${folder.name}" deleted.`);
}

// ─── Folder View (main pane) ──────────────────────────────────────────────────
function showFolderView(folderId) {
  const folder = getFolderById(folderId);
  if (!folder) return;
  currentFolderId = folderId;
  currentId = null;
  editingId = null;
  hideAll();
  clearActiveNav();

  // Expand the folder in the sidebar and mark it active
  collapsedFolders.delete(folderId);
  const sectionEl = document.querySelector(
    `.nav-folder[data-id="${CSS.escape(folderId)}"]`,
  );
  if (sectionEl) sectionEl.classList.remove("collapsed");
  document
    .querySelectorAll(".nav-folder-hdr")
    .forEach((el) =>
      el.classList.toggle(
        "active",
        el.closest(".nav-folder")?.dataset.id === folderId,
      ),
    );

  const folderCreds = credentials.filter((c) => c.folderId === folderId);
  document.getElementById("fv-name").textContent = folder.name;
  document.getElementById("fv-subtitle").textContent =
    `${folderCreds.length} credential${folderCreds.length !== 1 ? "s" : ""}`;

  const listEl = document.getElementById("fv-list");
  listEl.innerHTML = "";

  if (folderCreds.length === 0) {
    listEl.innerHTML = `
      <div style="text-align:center;padding:48px 0;color:var(--text-3)">
        <p style="margin-bottom:16px;font-size:14px">No credentials in this folder yet.</p>
        <button class="btn-primary" onclick="showAddForm('${folderId}')">Add Credential</button>
      </div>`;
  } else {
    // Group by category (same visual pattern as the rest of the app)
    const groups = {};
    for (const cred of folderCreds) {
      const cat = cred.category || "Other";
      (groups[cat] = groups[cat] || []).push(cred);
    }
    const sortedCats = Object.keys(groups).sort((a, b) => {
      const ia = CAT_ORDER.indexOf(a),
        ib = CAT_ORDER.indexOf(b);
      if (ia < 0 && ib < 0) return a.localeCompare(b);
      if (ia < 0) return 1;
      if (ib < 0) return -1;
      return ia - ib;
    });
    for (const cat of sortedCats) {
      const wrap = document.createElement("div");
      wrap.className = "fv-category";
      wrap.innerHTML = `<div class="fv-cat-lbl">${CATEGORIES[cat] || "📝"} ${escHtml(cat)}</div>`;
      const grid = document.createElement("div");
      grid.className = "fv-grid";
      for (const cred of groups[cat]) {
        const card = document.createElement("div");
        card.className = "fv-card";
        card.onclick = () => showDetail(cred.id);
        card.innerHTML = `
          <div class="fv-card-av" style="background:${avatarColor(cred.site)}">
            ${escHtml(cred.site.charAt(0).toUpperCase())}
          </div>
          <div class="fv-card-body">
            <div class="fv-card-name">${escHtml(cred.site)}</div>
            <div class="fv-card-user">${escHtml(cred.user || "—")}</div>
          </div>`;
        grid.appendChild(card);
      }
      wrap.appendChild(grid);
      listEl.appendChild(wrap);
    }
  }
  document.getElementById("folder-view").style.display = "block";
}

function startFolderTitleEdit() {
  const folder = getFolderById(currentFolderId);
  if (!folder) return;
  const titleEl = document.getElementById("fv-name");
  if (!titleEl || titleEl.tagName === "INPUT") return;
  const inp = document.createElement("input");
  inp.className = "fv-title-inp";
  inp.value = folder.name;
  inp.maxLength = 40;
  titleEl.replaceWith(inp);
  inp.focus();
  inp.select();
  let done = false;
  const commit = async () => {
    if (done) return;
    done = true;
    const n = inp.value.trim();
    if (n && n !== folder.name) {
      folder.name = n;
      folder.updatedAt = Date.now();
      await persistVault();
      renderSidebar();
      showToast(`Renamed to "${n}".`);
    }
    showFolderView(currentFolderId);
  };
  inp.addEventListener("keydown", (e) => {
    if (e.key === "Enter") {
      e.preventDefault();
      commit();
    }
    if (e.key === "Escape") {
      done = true;
      showFolderView(currentFolderId);
    }
  });
  inp.addEventListener("blur", () => setTimeout(commit, 150));
}

function deleteFolderFromView() {
  if (currentFolderId) deleteFolder(currentFolderId);
}

// ─── Password reveal ──────────────────────────────────────────────────────────
function togglePassView() {
  const passEl = document.getElementById("dtl-pass");
  const btn = document.getElementById("pass-toggle-btn");
  const shown = passEl.dataset.shown === "true";
  passEl.textContent = shown ? "••••••••••••" : passEl.dataset.pass;
  passEl.dataset.shown = shown ? "false" : "true";
  btn.textContent = shown ? "Show" : "Hide";
}

function toggleFormPass() {
  const inp = document.getElementById("f-pass");
  inp.type = inp.type === "password" ? "text" : "password";
}

// ─── Clipboard ────────────────────────────────────────────────────────────────
function copyEl(id) {
  const text = document.getElementById(id).textContent;
  navigator.clipboard.writeText(text).then(() => showToast("Copied!"));
}

function copyPassword() {
  const pass = document.getElementById("dtl-pass").dataset.pass;
  if (pass)
    navigator.clipboard
      .writeText(pass)
      .then(() => showToast("Password copied!"));
}

// ─── Export / Import helpers ──────────────────────────────────────────────────
function populateIOFolderSelects() {
  const sorted = [...folders].sort((a, b) => a.name.localeCompare(b.name));

  // Scope filter for export
  const expSel = document.getElementById("export-folder-filter");
  if (expSel) {
    expSel.innerHTML =
      `<option value="__all__">All Folders</option>` +
      `<option value="__none__">No Folder (unfiled only)</option>` +
      sorted
        .map(
          (f) => `<option value="${escHtml(f.id)}">${escHtml(f.name)}</option>`,
        )
        .join("");
  }

  // Override folder for import
  const impSel = document.getElementById("import-folder-override");
  if (impSel) {
    impSel.innerHTML =
      `<option value="">— No Folder —</option>` +
      sorted
        .map(
          (f) => `<option value="${escHtml(f.id)}">${escHtml(f.name)}</option>`,
        )
        .join("");
  }

  updateImportFolderUI();
}

function updateImportFolderUI() {
  const mode = document.querySelector(
    'input[name="import-folder-mode"]:checked',
  )?.value;
  const wrap = document.getElementById("import-override-wrap");
  if (wrap) wrap.style.display = mode === "override" ? "block" : "none";
}

// ─── Export ───────────────────────────────────────────────────────────────────
function exportCSV() {
  if (!credentials.length) {
    showToast("No credentials to export.");
    return;
  }

  // Read scope from dropdown
  const scope =
    document.getElementById("export-folder-filter")?.value ?? "__all__";
  let toExport;
  if (scope === "__all__") {
    toExport = credentials;
  } else if (scope === "__none__") {
    toExport = credentials.filter((c) => !c.folderId);
  } else {
    toExport = credentials.filter((c) => c.folderId === scope);
  }

  if (!toExport.length) {
    showToast("No credentials match the selected scope.");
    return;
  }

  const header = "site,user,pass,url,category,notes,folder";
  const rows = toExport.map((c) => {
    const folderName = c.folderId ? getFolderById(c.folderId)?.name || "" : "";
    return [
      c.site,
      c.user,
      c.pass,
      c.url || "",
      c.category || "",
      c.notes || "",
      folderName,
    ]
      .map(csvEsc)
      .join(",");
  });

  // Suffix filename with scope for clarity
  let suffix = "";
  if (scope === "__none__") {
    suffix = "-unfiled";
  } else if (scope !== "__all__") {
    const f = getFolderById(scope);
    if (f) suffix = `-${f.name.toLowerCase().replace(/[^a-z0-9]+/g, "-")}`;
  }

  const blob = new Blob([[header, ...rows].join("\n")], { type: "text/csv" });
  const url = URL.createObjectURL(blob);
  const a = Object.assign(document.createElement("a"), {
    href: url,
    download: `keyvault-export${suffix}-${new Date().toISOString().slice(0, 10)}.csv`,
  });
  a.click();
  URL.revokeObjectURL(url);
  showToast(
    `Exported ${toExport.length} credential${toExport.length !== 1 ? "s" : ""}.`,
  );
}

function csvEsc(val) {
  const s = String(val ?? "");
  return s.includes(",") || s.includes('"') || s.includes("\n")
    ? `"${s.replace(/"/g, '""')}"`
    : s;
}

// ─── Import ───────────────────────────────────────────────────────────────────
function handleDragOver(e) {
  e.preventDefault();
  document.getElementById("file-drop").classList.add("drag-over");
}
function handleDragLeave() {
  document.getElementById("file-drop").classList.remove("drag-over");
}
function handleDrop(e) {
  e.preventDefault();
  handleDragLeave();
  const f = e.dataTransfer.files[0];
  if (f) parseCSV(f);
}
function handleFileSelect(e) {
  const f = e.target.files[0];
  if (f) parseCSV(f);
  e.target.value = "";
}

function parseCSV(file) {
  const reader = new FileReader();
  reader.onload = async (e) => {
    const lines = e.target.result.trim().split(/\r?\n/);
    if (lines.length < 2) {
      showToast("CSV file appears empty.");
      return;
    }

    const headers = csvParseLine(lines[0]).map((h) => h.toLowerCase().trim());
    const idx = (name) => headers.indexOf(name);
    const si = idx("site"),
      pi = idx("pass");

    if (si < 0 || pi < 0) {
      showToast('"site" and "pass" columns are required.');
      return;
    }

    let added = 0;
    let skipped = 0;
    const now = Date.now();
    // Build a name→id map for folders so imports can resolve or create them
    const folderNameMap = new Map(
      folders.map((f) => [f.name.toLowerCase(), f.id]),
    );

    // Read import folder assignment mode from the UI
    const importMode =
      document.querySelector('input[name="import-folder-mode"]:checked')
        ?.value ?? "csv";
    const importOverrideId =
      importMode === "override"
        ? document.getElementById("import-folder-override")?.value || null
        : null;

    for (let i = 1; i < lines.length; i++) {
      if (!lines[i].trim()) continue;
      const cols = csvParseLine(lines[i]);
      const site = cols[si]?.trim();
      const pass = cols[pi]?.trim();
      if (!site || !pass) continue;

      // Extract user BEFORE generating the hash (user is part of the ID)
      const user = idx("user") >= 0 ? (cols[idx("user")] || "").trim() : "";
      const id = await generateHashId(site, user, pass);

      // Skip if an identical credential already exists
      if (credentials.some((c) => c.id === id)) {
        skipped++;
        continue;
      }

      // Resolve folder: UI override takes precedence over the CSV column
      let folderId = null;
      if (importMode === "override") {
        folderId = importOverrideId;
      } else {
        const fi = idx("folder");
        if (fi >= 0) {
          const folderName = (cols[fi] || "").trim();
          if (folderName) {
            const key = folderName.toLowerCase();
            if (folderNameMap.has(key)) {
              folderId = folderNameMap.get(key);
            } else {
              const nf = {
                id: genId(),
                name: folderName,
                createdAt: now,
                updatedAt: now,
              };
              folders.push(nf);
              folderNameMap.set(key, nf.id);
              folderId = nf.id;
            }
          }
        }
      }

      credentials.push({
        id,
        site,
        user,
        pass,
        folderId,
        url: idx("url") >= 0 ? (cols[idx("url")] || "").trim() : "",
        category:
          idx("category") >= 0
            ? (cols[idx("category")] || "Other").trim()
            : "Other",
        notes: idx("notes") >= 0 ? (cols[idx("notes")] || "").trim() : "",
        createdAt: now,
        updatedAt: now,
      });
      added++;
    }

    if (added > 0) await persistVault();
    renderSidebar();

    // Build a descriptive result message
    const parts = [];
    if (added > 0) parts.push(`${added} added`);
    if (skipped > 0)
      parts.push(`${skipped} skipped (duplicate${skipped !== 1 ? "s" : ""})`);
    const summary = parts.length
      ? parts.join(", ")
      : "No new credentials found.";
    showToast(`Import complete: ${summary}`, 3500);

    if (credentials.length && !currentId) showDetail(credentials[0].id);
  };
  reader.readAsText(file);
}

function csvParseLine(line) {
  const cols = [];
  let cur = "",
    inQ = false;
  for (let i = 0; i < line.length; i++) {
    const ch = line[i];
    if (ch === '"') {
      if (inQ && line[i + 1] === '"') {
        cur += '"';
        i++;
      } else inQ = !inQ;
    } else if (ch === "," && !inQ) {
      cols.push(cur);
      cur = "";
    } else cur += ch;
  }
  cols.push(cur);
  return cols;
}

// ─── Utilities ────────────────────────────────────────────────────────────────
function fmtDate(ts) {
  if (!ts) return "Unknown";
  return new Date(ts).toLocaleString(undefined, {
    year: "numeric",
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

const AVATAR_COLORS = [
  "#0a84ff",
  "#34c759",
  "#ff9f0a",
  "#ff453a",
  "#af52de",
  "#ff2d55",
  "#5ac8fa",
  "#30b0c7",
];
function avatarColor(name) {
  let h = 0;
  for (let i = 0; i < name.length; i++) h = name.charCodeAt(i) + ((h << 5) - h);
  return AVATAR_COLORS[Math.abs(h) % AVATAR_COLORS.length];
}

function escHtml(s) {
  return String(s)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function showToast(msg, duration = 2200) {
  clearTimeout(toastTimer);
  const t = document.getElementById("toast");
  t.textContent = msg;
  t.classList.add("show");
  toastTimer = setTimeout(() => t.classList.remove("show"), duration);
}

// ─── Settings view ────────────────────────────────────────────────────────────
function showSettings() {
  hideAll();
  clearActiveNav();
  // Populate timeout selector with persisted value
  const sel = document.getElementById("set-timeout");
  sel.value = String(loadSettings().autoLockMinutes ?? 15);
  // Clear any lingering status message
  const s = document.getElementById("settings-status");
  s.className = "settings-status";
  s.textContent = "";
  // Clear password fields
  ["set-cur-pass", "set-new-pass", "set-confirm-pass"].forEach(
    (id) => (document.getElementById(id).value = ""),
  );
  document.getElementById("settings-view").style.display = "block";
}

function saveAutoLockSetting() {
  const val = parseInt(document.getElementById("set-timeout").value, 10);
  const settings = loadSettings();
  settings.autoLockMinutes = val;
  saveSettings(settings);
  startAutoLock(); // restart with new timeout immediately
  const opt = TIMEOUT_OPTIONS.find((o) => o.value === val);
  showToast(
    val === 0
      ? "Auto-lock disabled."
      : `Auto-lock set to ${opt ? opt.label : val + " min"}.`,
  );
}

function showSettingsStatus(type, msg) {
  const el = document.getElementById("settings-status");
  el.className = `settings-status visible ${type}`;
  el.textContent = msg;
  if (type === "success") {
    setTimeout(() => {
      el.className = "settings-status";
      el.textContent = "";
    }, 5000);
  }
}

// Generic password field toggle used in settings
function toggleInpType(id) {
  const inp = document.getElementById(id);
  inp.type = inp.type === "password" ? "text" : "password";
}

async function changePassword() {
  const curPwd = document.getElementById("set-cur-pass").value;
  const newPwd = document.getElementById("set-new-pass").value;
  const confPwd = document.getElementById("set-confirm-pass").value;

  if (!curPwd || !newPwd || !confPwd) {
    showSettingsStatus("error", "Please fill in all three password fields.");
    return;
  }
  if (newPwd !== confPwd) {
    showSettingsStatus("error", "❌  New passwords do not match.");
    return;
  }
  if (newPwd.length < 8) {
    showSettingsStatus(
      "error",
      "❌  New password must be at least 8 characters.",
    );
    return;
  }

  const btn = document.getElementById("change-pass-btn");
  btn.disabled = true;
  btn.textContent = "Updating…";

  try {
    // 1. Verify the current password against the stored salt + vault
    const meta = await dbGet(META_KEY);
    if (!meta) throw new Error("Meta record not found.");
    const testKey = await deriveKey(curPwd, new Uint8Array(meta.salt));
    const vault = await dbGet(VAULT_KEY);
    if (vault) {
      try {
        await crypto.subtle.decrypt(
          { name: "AES-GCM", iv: new Uint8Array(vault.iv) },
          testKey,
          new Uint8Array(vault.data),
        );
      } catch {
        showSettingsStatus("error", "❌  Current password is incorrect.");
        return;
      }
    }

    // 2. Derive a new key with a fresh random salt
    const newSalt = crypto.getRandomValues(new Uint8Array(16));
    const newKey = await deriveKey(newPwd, newSalt);

    // 3. Re-encrypt the in-memory vault with the new key
    const iv = crypto.getRandomValues(new Uint8Array(12));
    const encrypted = await crypto.subtle.encrypt(
      { name: "AES-GCM", iv },
      newKey,
      new TextEncoder().encode(JSON.stringify({ credentials, folders })),
    );
    const newVaultPayload = {
      iv: Array.from(iv),
      data: Array.from(new Uint8Array(encrypted)),
    };

    // 4. Atomically persist new meta (salt) + new encrypted vault
    await dbPutMultiple([
      { key: META_KEY, value: { salt: Array.from(newSalt) } },
      { key: VAULT_KEY, value: newVaultPayload },
    ]);

    // 5. Promote the new key into memory
    cryptoKey = newKey;

    // 6. Clear fields & report success
    ["set-cur-pass", "set-new-pass", "set-confirm-pass"].forEach(
      (id) => (document.getElementById(id).value = ""),
    );
    showSettingsStatus("success", "✅  Master password changed successfully!");
    showToast("Master password updated.");
  } catch (err) {
    console.error(err);
    showSettingsStatus(
      "error",
      "⚠️  An unexpected error occurred. Please try again.",
    );
  } finally {
    btn.disabled = false;
    btn.textContent = "Change Password";
  }
}

// ─── Service Worker ───────────────────────────────────────────────────────────
if ("serviceWorker" in navigator) {
  navigator.serviceWorker.register("sw.js");
}
